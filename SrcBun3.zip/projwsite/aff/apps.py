from django.apps import AppConfig


class AffConfig(AppConfig):
    name = 'aff'
